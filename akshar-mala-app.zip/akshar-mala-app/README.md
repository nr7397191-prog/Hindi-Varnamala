# अक्षर माला – Hindi & English alphabet app

Nursery bachon ke liye: letters, awaaz, ungli se tracing, aur poora hone par "शाबाश / Well done".

## APK kaise banayein (GitHub par, free)
1. github.com par naya repository banao (jaise `akshar-mala`).
2. Is folder ki saari files upload karo (`.github` folder ke saath).
3. Repository mein **Actions** tab kholo. "Build APK" apne aap chalega (ya "Run workflow" dabao).
4. 3-5 minute baad us run mein neeche **Artifacts → akshar-mala-apk** milega. Download karke zip kholo, andar `app-debug.apk` hai.
5. Phone mein APK bhejo, install karo (Settings mein "Install unknown apps" allow karna padega).

## App badalna ho
Sirf `www/index.html` edit karo aur GitHub par commit karo. Naya APK apne aap ban jayega.
